# Rsettings
[termux users only]
helps you get admin password
wifi password and much more info from
backupsettings.conf file


# installation 
git clone https://github.com/termux4me/Rsettings.git
cd Rsettings
bash setup.sh




# usage
move backupsettings.conf to /sdcard/Download
Rsettings


