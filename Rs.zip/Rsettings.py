import di
di.keys()

# '''Rsettings''' helps you see your saved
#admin password from backupsettings.conf
#file and more information

print("enter \"A\" or \"a\" to see all details\n press entre to exit")
x=input('\x1b[41m\x1b[1m\x1b[37myour answer:\x1b[0m')
if x == "" :
   exit()
if x == "A" or x == "a" :
   di.all()
else :
   exit()
