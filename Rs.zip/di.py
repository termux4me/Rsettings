import base64, re
p="\x1b[32m         (())         (())\n          █\x1b[41m█           █\x1b[45m█\x1b[35m\n"
p=p+'          █\x1b[45m█           █\x1b[41m█\n'
p=p+'\x1b[44m\x1b[37m          █\x1b[45m█           █\x1b[41m█\n'
p=p+'       \x1b[37m█\x1b[41m█\x1b[44m█\x1b[41m██\x1b[45m██\x1b[45m██\x1b[45m█\x1b[45m██\x1b[45m██\x1b[45m██\x1b[45m█\x1b[45m██\x1b[45m██\n'
p=p+'    \x1b[45m██\x1b[41m█\x1b[42m█\x1b[45m██\x1b[44m██\x1b[45██\x1b[45m█\x1b[45m██\x1b[45m██\x1b[45m██\x1b[45m██\x1b[45m██\x1b[45m██\x1b[45m██\x1b[45m██\n'
p=p+'    \x1b[45m██       R.SETTINGS      \x1b[45m██\n'
p=p+'    \x1b[45m██\x1b[45m██\x1b[45m██\x1b[45m██\x1b[45m██\x1b[45m██\x1b[45m██\x1b[45m██\x1b[45m██\x1b[45m██\x1b[45m██\x1b[45m██\x1b[45m██\x1b[40m█\n'
f=open("/sdcard/Download/backupsettings.conf", "r")
def all():
        #time.sleep(1)
        f=open("/sdcard/Download/backupsettings.conf", "r")
        file=f.readlines()
        for x in file:
          #print(x)
          try:
           rep=re.search('>([^<]+)<', x)
           fep=re.search('([^<]+) <([^<]+)>', x)
           sep=re.sub('<([^<]+)</','',rep.string)
           sep=re.sub('([^<]+)</','',sep)
           sep=re.sub(' ([^<]+) ','',sep)
           sep=re.sub('</','',sep)
           sep=re.sub('>','',sep)
           sep=re.sub('<','',sep)
           sep=re.sub('$\n','',sep)
           per=re.sub('<([^<]+)>','',rep.string)
           en=re.sub(' ([^<]+) ','',per)
           b64s = base64.b64decode(en)
           b64 = str(b64s, "utf-8")
           print("\x1b[37m\x1b[1m", sep,":\x1b[0m\x1b[1m\x1b[37m", en,"\x1b[0m\x1b[34m\x1b[40m",'b64: \x1b[32m', b64, "\n")
          except:
           pass

def x(y,f=f):
	form=r'<' + re.escape(y) + '>([^<]+)</' + re.escape(y) + r">"
	file=f.readlines()
	for x in file:
	 try:
		 t4m=p+'                g'+'i'+'t'+'h'+'u'+'b'+'.'+'c'+'o'+'m'+'/'+'t'+'e'+'r'+'m'+'u'+'x'+'4'+'m'+'e\n\n\n\n'
		 rep=re.search(form, x)
		 per=re.sub('<([^<]+)>','',rep.string)
		 en=re.sub(' ([^<]+) ','',per)
		 decodedBytes = base64.b64decode(en)
		 decodedStr = str(decodedBytes, "utf-8")
		 print(t4m,'\n','\x1b[44m██████████████████████ ██████████ █ ██ █ ████████ █████████\x1b[40m\n',y,' : \x1b[1m      ' + decodedStr,'\n\x1b[37m')
	 except:
	 	pass
f=open("/sdcard/Download/backupsettings.conf", "r")
def t(y,f=f):
	form=r'<' + re.escape(y) + '>([^<]+)</' + re.escape(y) + r">"
	file=f.readlines()
	fil=open('b.n', "a+")
	for x in file:
	 try:
		 rep=re.search(form, x)
		 per=re.sub('<([^<]+)>','',rep.string)
		 en=re.sub(' ([^<]+) ','',per)
		 print(y,' :       ' + en,'\n\x1b[44m██████████████████████ ██████████ █ ██ █ ████████ █████████\x1b[40m\x1b[32m')
	 except:
		 pass
def adp():
	x("AdminPassword")
def key():
	t("WlWpaPsk")
def keys():
	adp()
	key()


